import type { Metadata } from "next"
import { Geist_Mono, Roboto } from "next/font/google"
import "./globals.css"
import { AppSidebar } from "@/components/app-sidebar"

const roboto = Roboto({
  variable: "--font-roboto",
  subsets: ["latin"],
  weight: ["400", "500", "700"],
})

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
})

export const metadata: Metadata = {
  title: "InnoventSoft Automation",
  description: "A simple interface to upload videos and automate publishing using workflows.",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body
        className={`${roboto.variable} ${geistMono.variable} antialiased`}
        style={{ background: "#F8FAFC", display: "flex", minHeight: "100vh" }}
      >
          <AppSidebar />
          {/* Main content offset by sidebar width */}
          <main style={{ marginLeft: 288, flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", height: "100vh" }}>
            {children}
          </main>
      </body>
    </html>
  )
}
