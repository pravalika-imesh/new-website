import React from 'react'
import { UploadVideosTab } from '@/components/upload-videos-tab'

const page = () => {
  return (
      <UploadVideosTab />
  )
}

export default page
