import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    const title = formData.get('title') as string
    const targetAudience = formData.get('targetAudience') as string
    const publishDate = formData.get('publishDate') as string
    const videoFile = formData.get('videoFile') as File

    if (!videoFile) {
      return NextResponse.json({ success: false, error: 'No video file provided' }, { status: 400 })
    }

    // Build a new FormData with the actual binary file
    const forwardFormData = new FormData()
    forwardFormData.append('title', title)
    forwardFormData.append('targetAudience', targetAudience)
    forwardFormData.append('publishDate', publishDate)
    forwardFormData.append('related_Videos', videoFile, videoFile.name) // key matches n8n "Input Data Field Name"

    const response = await fetch('https://imesh1234.app.n8n.cloud/webhook/youtube automation', {
      method: 'POST',
      body: forwardFormData,
      // Do NOT set Content-Type header — fetch sets it automatically with the correct boundary
    })

    const responseText = await response.text()
    console.log('n8n response:', response.status, responseText)

    if (!response.ok) {
      return NextResponse.json(
        { success: false, error: `n8n responded with ${response.status}: ${responseText}` },
        { status: 502 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('API route error:', error)
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 })
  }
}