'use client'

import { useState, useRef, useEffect } from 'react'
import { ChevronDown, X, Users } from 'lucide-react'
import { cn } from '@/lib/utils'

interface TargetAudienceSelectProps {
  value: string[]
  onChange: (value: string[]) => void
}

const audienceOptions = [
  { id: 'youth', label: 'Youth (13-17)', icon: '👨‍🎓' },
  { id: 'young-adults', label: 'Young Adults (18-25)', icon: '👨‍💼' },
  { id: 'adults', label: 'Adults (26-40)', icon: '👨‍💻' },
  { id: 'mature', label: 'Mature (40+)', icon: '👴' },
  { id: 'all-ages', label: 'All Ages', icon: '👨‍👩‍👧‍👦' },
]

export function TargetAudienceSelect({ value, onChange }: TargetAudienceSelectProps) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const toggleOption = (optionId: string) => {
    if (value.includes(optionId)) {
      onChange(value.filter((id) => id !== optionId))
    } else {
      onChange([...value, optionId])
    }
  }

  const handleRemoveTag = (optionId: string) => {
    onChange(value.filter((id) => id !== optionId))
  }

  const selectedLabels = value
    .map((id) => audienceOptions.find((opt) => opt.id === id)?.label)
    .filter(Boolean) as string[]

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Dropdown Trigger */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          'w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-lg border transition-all duration-200',
          isOpen
            ? 'border-blue-500 ring-2 ring-blue-100 bg-white'
            : 'border-slate-200 bg-white hover:border-slate-300'
        )}
      >
        <div className="flex items-center gap-2 min-w-0">
          <Users size={18} className="text-slate-600 flex-shrink-0" />
          <span className={cn(
            'text-sm',
            value.length > 0 ? 'text-slate-900' : 'text-slate-500'
          )}>
            {value.length > 0
              ? `${value.length} selected`
              : 'Select audience groups'}
          </span>
        </div>
        <ChevronDown
          size={18}
          className={cn(
            'text-slate-600 flex-shrink-0 transition-transform duration-200',
            isOpen && 'rotate-180'
          )}
        />
      </button>

      {/* Selected Tags */}
      {value.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-3">
          {value.map((optionId) => {
            const option = audienceOptions.find((opt) => opt.id === optionId)
            return (
              <div
                key={optionId}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 border border-blue-200"
              >
                <span className="text-sm">{option?.icon}</span>
                <span className="text-sm font-medium text-blue-700">{option?.label}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveTag(optionId)}
                  className="ml-1 hover:bg-blue-200 rounded-full p-0.5 transition-colors"
                >
                  <X size={14} className="text-blue-600" />
                </button>
              </div>
            )
          })}
        </div>
      )}

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-lg shadow-lg z-50 overflow-hidden">
          <div className="p-2 space-y-1 max-h-64 overflow-y-auto">
            {audienceOptions.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => toggleOption(option.id)}
                className={cn(
                  'w-full text-left flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-200',
                  value.includes(option.id)
                    ? 'bg-blue-50 border border-blue-200'
                    : 'hover:bg-slate-50 border border-transparent'
                )}
              >
                <div className={cn(
                  'w-5 h-5 rounded border transition-all duration-200 flex items-center justify-center flex-shrink-0',
                  value.includes(option.id)
                    ? 'bg-blue-500 border-blue-500'
                    : 'border-slate-300 hover:border-slate-400'
                )}>
                  {value.includes(option.id) && (
                    <svg className="w-3 h-3 text-white" viewBox="0 0 20 20" fill="currentColor">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  )}
                </div>
                <span className="text-lg">{option.icon}</span>
                <div className="flex-1">
                  <p className={cn(
                    'text-sm font-medium',
                    value.includes(option.id) ? 'text-blue-900' : 'text-slate-900'
                  )}>
                    {option.label}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
