'use client'

import { useCallback, useState } from 'react'
import { Upload, Video, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface VideoFileUploadProps {
  onFileSelect: (file: File) => void
  selectedFile?: File
}

export function VideoFileUpload({ onFileSelect, selectedFile }: VideoFileUploadProps) {
  const [isDragActive, setIsDragActive] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const validateFile = (file: File): boolean => {
    const videoTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo']
    
    if (!videoTypes.includes(file.type)) {
      setError('Invalid video format. Supported formats: MP4, WebM, MOV, AVI')
      return false
    }

    if (file.size > 500 * 1024 * 1024) {
      setError('Video file must be 500MB or less')
      return false
    }

    setError(null)
    return true
  }

  const handleDrag = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      e.stopPropagation()
      if (e.type === 'dragenter' || e.type === 'dragover') {
        setIsDragActive(true)
      } else if (e.type === 'dragleave') {
        setIsDragActive(false)
      }
    },
    []
  )

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      e.stopPropagation()
      setIsDragActive(false)

      const files = e.dataTransfer.files
      if (files && files[0]) {
        const file = files[0]
        if (validateFile(file)) {
          onFileSelect(file)
        }
      }
    },
    [onFileSelect]
  )

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files[0]) {
      const file = files[0]
      if (validateFile(file)) {
        onFileSelect(file)
      }
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i]
  }

  const handleRemoveFile = (e: React.MouseEvent) => {
    e.preventDefault()
    onFileSelect(undefined as any)
    setError(null)
  }

  return (
    <div className="space-y-4">
      {!selectedFile ? (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={cn(
            'relative rounded-lg border-2 border-dashed p-8 sm:p-12 text-center transition-all duration-200 cursor-pointer',
            isDragActive
              ? 'border-blue-500 bg-blue-50 scale-105'
              : 'border-slate-300 bg-slate-50 hover:border-slate-400 hover:bg-slate-100'
          )}
        >
          <input
            type="file"
            accept="video/*"
            onChange={handleInputChange}
            className="absolute inset-0 opacity-0 cursor-pointer"
            aria-label="Upload video file"
          />

          <div className="flex flex-col items-center gap-3">
            <div className={cn(
              'p-3 rounded-full transition-colors',
              isDragActive ? 'bg-blue-100' : 'bg-slate-200'
            )}>
              <Upload
                size={32}
                className={cn(
                  'transition-colors',
                  isDragActive ? 'text-blue-600' : 'text-slate-600'
                )}
              />
            </div>
            <div>
              <p className="text-lg font-semibold text-slate-900">
                Drag and drop your video here
              </p>
              <p className="text-sm text-slate-600 mt-1">
                or <span className="text-blue-600 font-medium">click to browse</span>
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              <span className="px-3 py-1 rounded-full bg-white text-sm text-slate-600 border border-slate-200">
                MP4
              </span>
              {/* <span className="px-3 py-1 rounded-full bg-white text-sm text-slate-600 border border-slate-200">
                WebM
              </span>
              <span className="px-3 py-1 rounded-full bg-white text-sm text-slate-600 border border-slate-200">
                MOV
              </span> */}
            </div>
            {/* <p className="text-xs text-slate-500 mt-2">Maximum file size: 500MB</p> */}
          </div>
        </div>
      ) : (
        <div className="rounded-lg border border-slate-200 bg-gradient-to-br from-green-50 to-emerald-50 p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4 flex-1 min-w-0">
              <div className="p-3 rounded-lg bg-green-100 flex-shrink-0 mt-1">
                <Video size={24} className="text-green-600" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-slate-900 text-sm truncate">
                  {selectedFile.name}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full w-full bg-green-500 rounded-full" />
                  </div>
                  <span className="text-xs text-slate-600 flex-shrink-0">
                    {formatFileSize(selectedFile.size)}
                  </span>
                </div>
                <p className="text-xs text-green-600 mt-1 font-medium">✓ Ready to upload</p>
              </div>
            </div>
            <button
              onClick={handleRemoveFile}
              className="p-2 hover:bg-slate-200 rounded-lg transition-colors flex-shrink-0"
              aria-label="Remove video file"
            >
              <X size={20} className="text-slate-600" />
            </button>
          </div>
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700 font-medium">✗ {error}</p>
        </div>
      )}
    </div>
  )
}
