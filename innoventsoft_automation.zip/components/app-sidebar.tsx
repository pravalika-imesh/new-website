"use client"

import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import Image from "next/image"
import { Upload, Clapperboard, ChevronRight } from "lucide-react"

interface NavItem {
  label: string
  href: string
  icon: React.ElementType
}


const NAV_ITEMS: NavItem[] = [
  {
    label: "Upload Videos",
    href: "/upload-videos",
    icon: Upload,
  },
//   {
//     label: "Create Videos",
//     href: "/create-videos",
//     icon: Clapperboard,
//   },
]

export function AppSidebar() {
  const pathname = usePathname()
  const router = useRouter()

  return (
    <div
      className="w-72 h-screen fixed left-0 top-0 flex flex-col overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #001F48 0%, #004198 100%)",
        borderRight: "1px solid #1e3a6e",
        zIndex: 50,
      }}
    >
      {/* ── Brand header ─────────────────────────────── */}
      <div
        className="flex-shrink-0 flex items-center px-5 py-4"
        style={{ borderBottom: "1px solid #1e3a6e" }}
      >
        <Image
          src="/Innoventsoft-logo.png"
          alt="Innoventsoft logo"
          width={180}
          height={48}
          priority
          className="object-contain"
        />
      </div>


      {/* ── Nav items ─────────────────────────────────── */}
      <nav className="flex-1 overflow-y-auto px-3 space-y-1 pt pt-6">
        {NAV_ITEMS.map(item => {
          const Icon = item.icon
          const active = pathname === item.href || pathname.startsWith(item.href + "/")

          return (
            <button
              key={item.href}
              onClick={() => router.push(item.href)}
              className={cn(
                "group relative w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all duration-200 cursor-pointer",
                active
                  ? "bg-white/10 text-white shadow-lg shadow-black/20"
                  : "text-blue-200/70 hover:bg-white/5 hover:text-blue-100"
              )}
            >
              {/* Active accent bar */}
              {active && (
                <div
                  className="absolute left-0 top-2 bottom-2 w-1 rounded-full"
                  style={{ background: "linear-gradient(180deg, #60a5fa, #818cf8)" }}
                />
              )}

              {/* Icon */}
              <div
                className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all",
                  active
                    ? "bg-blue-500/30"
                    : "bg-white/5 group-hover:bg-white/10"
                )}
              >
                <Icon className={cn("w-4 h-4", active ? "text-blue-300" : "text-blue-400/70")} />
              </div>

              {/* Label + description */}
              <div className="flex-1 min-w-0">
                <div className={cn("font-semibold text-sm", active ? "text-white" : "")}>
                  {item.label}
                </div>
                {/* <div className="text-xs text-blue-300/50 truncate mt-0.5">{item.description}</div> */}
              </div>

              {/* Trailing chevron */}
              <ChevronRight
                className={cn(
                  "w-4 h-4 flex-shrink-0 transition-all",
                  active ? "text-blue-400 opacity-100" : "opacity-0 group-hover:opacity-40"
                )}
              />
            </button>
          )
        })}
      </nav>

    </div>
  )
}
