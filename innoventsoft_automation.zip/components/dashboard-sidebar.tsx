'use client'

import { Upload, BarChart3, Settings, User } from 'lucide-react'
import { cn } from '@/lib/utils'

interface DashboardSidebarProps {
  activeTab: 'upload' | 'analytics' | 'settings' | 'profile'
  onTabChange: (tab: 'upload' | 'analytics' | 'settings' | 'profile') => void
}

const tabs = [
  {
    id: 'upload' as const,
    label: 'Upload Videos',
    icon: Upload,
  },
  {
    id: 'analytics' as const,
    label: 'Analytics',
    icon: BarChart3,
  },
  {
    id: 'settings' as const,
    label: 'Settings',
    icon: Settings,
  },
  {
    id: 'profile' as const,
    label: 'Profile',
    icon: User,
  },
]

export function DashboardSidebar({ activeTab, onTabChange }: DashboardSidebarProps) {
  return (
    <aside className="hidden sm:flex w-64 bg-slate-900 text-white flex-col border-r border-slate-800">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
          ContentHub
        </h1>
        <p className="text-sm text-slate-400 mt-1">Video Management Platform</p>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-sm font-medium',
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              )}
            >
              <Icon size={20} />
              <span>{tab.label}</span>
            </button>
          )
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-slate-800">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-cyan-400" />
          <div className="text-left min-w-0">
            <p className="text-sm font-medium text-white truncate">Creator</p>
            <p className="text-xs text-slate-400 truncate">user@example.com</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
