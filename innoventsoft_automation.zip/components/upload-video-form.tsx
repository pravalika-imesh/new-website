'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Spinner } from '@/components/ui/spinner'
import { VideoFileUpload } from '@/components/video-file-upload'
import { DatePicker } from '@/components/date-picker'

const formSchema = z.object({
  title: z
    .string()
    .min(1, 'Title is required')
    .max(100, 'Title must be 100 characters or less'),
  targetAudience: z
    .string()
    .min(1, 'Target audience is required'),
  videoFile: z
    .instanceof(File)
    .refine((file) => file.size <= 500 * 1024 * 1024, 'Video must be 500MB or less')
    .refine(
      (file) => file.type === 'video/mp4',
      'Invalid video format. Only MP4 files are supported'
    ),
  publishDate: z.date().refine(
    (date) => date > new Date(),
    'Publishing date must be in the future'
  ),
})

type FormValues = z.infer<typeof formSchema>

export function UploadVideoForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      targetAudience: '',
      videoFile: undefined as any,
      publishDate: undefined as any,
    },
  })

  const onSubmit = async (data: FormValues) => {
    try {
      setIsSubmitting(true)

      const formData = new FormData()
      formData.append('title', data.title)
      formData.append('targetAudience', data.targetAudience)
      formData.append('videoFile', data.videoFile, data.videoFile.name)
      formData.append('publishDate', data.publishDate.toLocaleDateString('en-CA'))

      const response = await fetch('/api/upload-video', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Webhook responded with status ${response.status}`)
      }

      toast.success('Video uploaded successfully!', {
        description: `"${data.title}" has been scheduled for publishing on ${data.publishDate.toLocaleDateString()}.`,
        duration: 4000,
      })

      form.reset()
    } catch (error) {
      toast.error('Failed to upload video', {
        description: 'Please try again later.',
        duration: 4000,
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 sm:p-8 space-y-2">
      {/* Title Field */}
      <div className="space-y-1">
        <Label htmlFor="title" className="text-base font-semibold text-slate-900">
          Video Title
        </Label>
        <p className="text-sm text-slate-500">Give your video a catchy and descriptive title</p>
        <div className="relative">
          <Input
            id="title"
            placeholder="Enter your video title"
            className="text-base py-2.5 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
            {...form.register('title')}
          />
          {form.watch('title') && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-slate-500">
              {form.watch('title').length}/100
            </span>
          )}
        </div>
        {form.formState.errors.title && (
          <p className="text-sm text-red-500 mt-1">{form.formState.errors.title.message}</p>
        )}
      </div>

      {/* Target Audience Field */}
      <div className="space-y-1">
        <Label htmlFor="targetAudience" className="text-base font-semibold text-slate-900">
          Target Audience
        </Label>
        <p className="text-sm text-slate-500">Describe the audience you want to reach</p>
        <Input
          id="targetAudience"
          placeholder="e.g. Young professionals aged 25–34"
          className="text-base py-2.5 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
          {...form.register('targetAudience')}
        />
        {form.formState.errors.targetAudience && (
          <p className="text-sm text-red-500 mt-1">
            {form.formState.errors.targetAudience.message}
          </p>
        )}
      </div>

      {/* Video File Upload Field */}
      <div className="space-y-1">
        <Label className="text-base font-semibold text-slate-900">
          Video File
        </Label>
        <p className="text-sm text-slate-500">Upload your video file (MP4 only)</p>
        <VideoFileUpload
          onFileSelect={(file) => form.setValue('videoFile', file)}
          selectedFile={form.watch('videoFile')}
          accept="video/mp4"
        />
        {form.formState.errors.videoFile && (
          <p className="text-sm text-red-500 mt-1">{form.formState.errors.videoFile.message}</p>
        )}
      </div>

      {/* Publish Date Field */}
      <div className="space-y-2">
        <Label className="text-base font-semibold text-slate-900">
          Date of Publishing
        </Label>
        <p className="text-sm text-slate-500">Choose when you want your video to be published</p>
        <DatePicker
          value={form.watch('publishDate')}
          onChange={(date) => form.setValue('publishDate', date)}
        />
        {form.formState.errors.publishDate && (
          <p className="text-sm text-red-500 mt-1">
            {form.formState.errors.publishDate.message}
          </p>
        )}
      </div>

      {/* Submit Button */}
      <div className="flex gap-3 pt-6 border-t border-slate-200">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 text-base font-medium rounded-lg transition-colors"
        >
          {isSubmitting ? (
            <>
              <Spinner className="mr-2 h-4 w-4" />
              Submitting...
            </>
          ) : (
            'Submit Details'
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => form.reset()}
          className="px-6 py-2.5 border-slate-300 text-slate-700 hover:bg-slate-50"
          disabled={isSubmitting}
        >
          Reset
        </Button>
      </div>
    </form>
  )
}