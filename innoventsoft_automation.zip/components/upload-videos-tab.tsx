'use client'

import { UploadVideoForm } from '@/components/upload-video-form'

export function UploadVideosTab() {
  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 sm:p-8 sm:py-3">
      <div className="max-w-3xl">
        {/* Header */}
        <div className="mb-2">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 text-balance">
            Upload Your Video
          </h1>
          <p className="text-slate-600 mt-2 text-balance">
            Share your content with the world. Fill in the details below to get started.
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-xl shadow-lg border border-slate-200">
          <UploadVideoForm />
        </div>
      </div>
    </div>
  )
}
