'use client'

import { useState, useRef, useEffect } from 'react'
import { Calendar, ChevronLeft, ChevronRight, ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

interface DatePickerProps {
  value?: Date
  onChange: (date: Date) => void
}

export function DatePicker({ value, onChange }: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [openUpward, setOpenUpward] = useState(false)
  const [currentMonth, setCurrentMonth] = useState(value || new Date())
  const datePickerRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (datePickerRef.current && !datePickerRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleToggle = () => {
    if (!isOpen && triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect()
      const spaceBelow = window.innerHeight - rect.bottom
      // Calendar is roughly 320px tall
      setOpenUpward(spaceBelow < 320)
    }
    setIsOpen((prev) => !prev)
  }

  const getDaysInMonth = (date: Date) =>
    new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()

  const getFirstDayOfMonth = (date: Date) =>
    new Date(date.getFullYear(), date.getMonth(), 1).getDay()

  const days = Array.from({ length: getDaysInMonth(currentMonth) }, (_, i) => i + 1)
  const emptyDays = Array.from({ length: getFirstDayOfMonth(currentMonth) }, () => null)
  const calendarDays = [...emptyDays, ...days]

  const handleDateClick = (day: number) => {
    const selectedDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    onChange(selectedDate)
    setIsOpen(false)
  }

  const handlePreviousMonth = () =>
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))

  const handleNextMonth = () =>
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))

  const formatDate = (date: Date | undefined) => {
    if (!date) return ''
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
  }

  const isDateDisabled = (day: number) => {
    const checkDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    return checkDate <= today
  }

  const isDateSelected = (day: number) => {
    if (!value) return false
    return (
      value.getDate() === day &&
      value.getMonth() === currentMonth.getMonth() &&
      value.getFullYear() === currentMonth.getFullYear()
    )
  }

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ]
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

  return (
    <div className="relative" ref={datePickerRef}>
      {/* Trigger */}
      <button
        ref={triggerRef}
        type="button"
        onClick={handleToggle}
        className={cn(
          'w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-lg border transition-all duration-200',
          isOpen
            ? 'border-blue-500 ring-2 ring-blue-100 bg-white'
            : 'border-slate-200 bg-white hover:border-slate-300'
        )}
      >
        <div className="flex items-center gap-3 min-w-0">
          <Calendar size={18} className="text-slate-400 flex-shrink-0" />
          <span className={cn('text-sm', value ? 'text-slate-900 font-medium' : 'text-slate-500')}>
            {value ? formatDate(value) : 'Select publishing date'}
          </span>
        </div>
        <ChevronDown
          size={18}
          className={cn(
            'text-slate-400 flex-shrink-0 transition-transform duration-200',
            isOpen && 'rotate-180'
          )}
        />
      </button>

      {/* Calendar Popover */}
      {isOpen && (
        <div
          className={cn(
            'absolute left-0 z-50 bg-white border border-slate-200 rounded-xl shadow-xl p-4 w-72',
            openUpward ? 'bottom-full mb-2' : 'top-full mt-2'
          )}
        >
          {/* Month Header */}
          <div className="flex items-center justify-between mb-3">
            <button
              type="button"
              onClick={handlePreviousMonth}
              className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ChevronLeft size={16} className="text-slate-600" />
            </button>
            <h3 className="font-semibold text-slate-900 text-sm">
              {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
            </h3>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ChevronRight size={16} className="text-slate-600" />
            </button>
          </div>

          {/* Day Headers */}
          <div className="grid grid-cols-7 mb-1">
            {dayNames.map((day) => (
              <div key={day} className="text-center text-xs font-semibold text-slate-400 py-1.5">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-y-0.5">
            {calendarDays.map((day, index) => {
              const isDisabled = day === null || isDateDisabled(day)
              const isSelected = day !== null && isDateSelected(day)

              return (
                <button
                  key={`${index}-${day}`}
                  type="button"
                  onClick={() => day !== null && !isDisabled && handleDateClick(day)}
                  disabled={isDisabled}
                  className={cn(
                    'h-8 w-full text-xs rounded-lg font-medium transition-all duration-150',
                    day === null && 'invisible',
                    day !== null && !isDisabled && !isSelected &&
                      'text-slate-800 hover:bg-blue-50 hover:text-blue-600 cursor-pointer',
                    isSelected && 'bg-blue-500 text-white hover:bg-blue-600 shadow-sm',
                    isDisabled && day !== null && 'text-slate-300 cursor-not-allowed'
                  )}
                >
                  {day}
                </button>
              )
            })}
          </div>

          {/* Helper Text */}
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5">
            <Calendar size={12} className="text-slate-400 flex-shrink-0" />
            <p className="text-xs text-slate-400">Only future dates can be selected</p>
          </div>
        </div>
      )}
    </div>
  )
}